import { ArrayType } from "@angular/compiler";
import { FormControl } from "@angular/forms";

export class Resetpassword {

  title = 'Reset Password';
  email: string;

}