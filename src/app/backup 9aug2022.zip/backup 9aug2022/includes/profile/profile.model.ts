import { ArrayType } from "@angular/compiler";
import { FormControl } from "@angular/forms";

export class Profile {

  title = 'appBootstrap';
  email: string;
  password: string;
  name: string;
  phone: string;

}