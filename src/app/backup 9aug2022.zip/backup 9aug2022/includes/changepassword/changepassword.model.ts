import { ArrayType } from "@angular/compiler";
import { FormControl } from "@angular/forms";

export class Changepassword {

  title = 'Update Password';
  email: string;
  newpassword: any;
  password: any;

}