import { ArrayType } from "@angular/compiler";
import { FormControl } from "@angular/forms";

export class Login {

  title = 'appBootstrap';
  email: string;
  password: string;

}